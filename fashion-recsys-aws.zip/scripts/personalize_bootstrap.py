import argparse, time, json
import boto3

# Bootstrap Amazon Personalize:
#   - Create dataset group
#   - Create item schema
#   - Create items dataset
#   - Create import job (from S3 export path)
#   - Create solution / solution version
#   - Create campaign
#
# NOTE: Provide an IAM Role for Personalize that grants s3:GetObject on your export bucket.

ITEM_SCHEMA = {
  "type": "record",
  "name": "Items",
  "namespace": "com.amazonaws.personalize.schema",
  "fields": [
    {"name": "ITEM_ID", "type": "string"},
    {"name": "TITLE", "type": ["null","string"], "categorical": False},
    {"name": "GENRES", "type": ["null","string"], "categorical": True},
    {"name": "LABELS", "type": ["null","string"], "categorical": True},
    {"name": "IMAGE_URL", "type": ["null","string"]}
  ],
  "version": "1.0"
}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--region", required=True)
    p.add_argument("--dataset-group-name", required=True)
    p.add_argument("--bucket", required=True)
    p.add_argument("--prefix", default="personalize/items/")
    p.add_argument("--role-arn", required=True, help="IAM Role ARN for Personalize to access S3 data")
    p.add_argument("--recipe-arn", default="arn:aws:personalize:::recipe/aws-user-personalization")
    p.add_argument("--campaign-name", default="fashion-campaign")
    args = p.parse_args()

    session = boto3.Session(region_name=args.region)
    pz = session.client("personalize")

    # 1) Dataset group
    dg = pz.create_dataset_group(name=args.dataset_group_name)
    dg_arn = dg["datasetGroupArn"]
    wait_for_status(pz, "dataset-group", dg_arn)

    # 2) Item schema
    schema = pz.create_schema(
        name=f"{args.dataset_group_name}-item-schema",
        schema=json.dumps(ITEM_SCHEMA)
    )
    schema_arn = schema["schemaArn"]

    # 3) Items dataset
    ds = pz.create_dataset(
        name=f"{args.dataset_group_name}-items",
        datasetType="ITEMS",
        datasetGroupArn=dg_arn,
        schemaArn=schema_arn
    )
    ds_arn = ds["datasetArn"]
    wait_for_status(pz, "dataset", ds_arn)

    # 4) Import job (latest CSV in prefix)
    s3 = session.client("s3")
    resp = s3.list_objects_v2(Bucket=args.bucket, Prefix=args.prefix)
    if not resp.get("Contents"):
        raise SystemExit("No CSV found in S3 prefix. Run the export Lambda first.")
    latest = sorted(resp["Contents"], key=lambda o: o["LastModified"], reverse=True)[0]["Key"]

    import_job = pz.create_dataset_import_job(
        jobName=f"{args.dataset_group_name}-items-import",
        datasetArn=ds_arn,
        dataSource={
            "dataLocation": f"s3://{args.bucket}/{latest}"
        },
        roleArn=args.role_arn
    )
    import_arn = import_job["datasetImportJobArn"]
    wait_for_status(pz, "dataset-import-job", import_arn)

    # 5) Solution & solution version
    sol = pz.create_solution(
        name=f"{args.dataset_group_name}-solution",
        datasetGroupArn=dg_arn,
        recipeArn=args.recipe_arn
    )
    sol_arn = sol["solutionArn"]

    sv = pz.create_solution_version(solutionArn=sol_arn)
    sv_arn = sv["solutionVersionArn"]
    wait_for_status(pz, "solution-version", sv_arn)

    # 6) Campaign
    camp = pz.create_campaign(
        name=args.campaign_name,
        solutionVersionArn=sv_arn,
        minProvisionedTPS=1
    )
    camp_arn = camp["campaignArn"]

    print(json.dumps({
        "datasetGroupArn": dg_arn,
        "schemaArn": schema_arn,
        "itemsDatasetArn": ds_arn,
        "datasetImportJobArn": import_arn,
        "solutionArn": sol_arn,
        "solutionVersionArn": sv_arn,
        "campaignArn": camp_arn
    }, indent=2))

def wait_for_status(pz, kind, arn):
    while True:
        if kind == "dataset-group":
            st = pz.describe_dataset_group(datasetGroupArn=arn)["datasetGroup"]["status"]
        elif kind == "dataset":
            st = pz.describe_dataset(datasetArn=arn)["dataset"]["status"]
        elif kind == "dataset-import-job":
            st = pz.describe_dataset_import_job(datasetImportJobArn=arn)["datasetImportJob"]["status"]
        elif kind == "solution-version":
            st = pz.describe_solution_version(solutionVersionArn=arn)["solutionVersion"]["status"]
        else:
            st = "ACTIVE"
        if st in ("ACTIVE","CREATE FAILED","CREATE_FAILED","DELETE_FAILED"):
            print(f"{kind} {arn} -> {st}")
            if "FAILED" in st:
                raise RuntimeError(f"{kind} {arn} failed")
            return
        time.sleep(15)

if __name__ == "__main__":
    main()
