# Fashion Recommendation System on AWS (Serverless)

This repository contains a production-ready, serverless reference implementation of a
**fashion recommendation system** on AWS. It uses an **event-driven** workflow
orchestrated by **AWS Step Functions**. New images uploaded to **Amazon S3**
are analyzed by **Amazon Rekognition**, and extracted features are stored in
**Amazon DynamoDB**. Data is periodically exported to S3 and fed into
**Amazon Personalize** to train and serve recommendations.

## Architecture (Option A - Amazon Personalize)

**Flow**:
1. Upload image to S3 (e.g., `fashion-images-raw`).
2. S3 event → Lambda (`IngestFunction`) → starts Step Functions execution.
3. Step Functions runs two tasks:
   - `RekognitionFunction`: Detects labels and basic colors/categories.
   - `DdbWriterFunction`: Persists metadata & features in DynamoDB.
4. A scheduled Lambda (`ExportForPersonalizeFunction`) dumps a flattened
   item catalog from DynamoDB → S3 (CSV) and can trigger Personalize import.

## Deploy (AWS SAM)

**Prereqs**:
- AWS account & credentials configured locally
- AWS SAM CLI
- Python 3.10+

**One-time**:
```bash
sam build
sam deploy --guided
```
During `--guided` set these parameters:
- `RawImagesBucketName` (e.g., `fashion-images-raw-<your-suffix>`)
- `ProcessedDataBucketName` (for exports, e.g., `fashion-exports-<your-suffix>`)
- `DynamoTableName` (e.g., `fashion-products`)
- `CreateSchedule` (Y/N) to enable a daily export job

After deploy, upload images to your **raw images bucket** and watch executions in
Step Functions. Check DynamoDB for items.

## Bootstrap Amazon Personalize (optional but recommended)

The script at `scripts/personalize_bootstrap.py` can **create** a dataset group,
item schema, datasets, a solution (SIMS / user-personalization), and a campaign.
It expects the S3 path where the export job writes the CSV.

```bash
# activate your venv first, ensure boto3 installed
python scripts/personalize_bootstrap.py   --region <REGION>   --dataset-group-name fashion-recsys   --bucket <ProcessedDataBucketName>   --prefix personalize/items/   --role-arn arn:aws:iam::<ACCOUNT_ID>:role/<PersonalizeAccessRole>
```

The bootstrap will print created resource ARNs. You can then call the campaign's
**GetRecommendations** API from your app layer.

## Repo Layout

```text
fashion-recsys-aws/
├─ template.yaml                # SAM/CloudFormation infra
├─ src/
│  ├─ ingest_handler.py         # S3 -> Start Step Functions
│  ├─ rekognition_handler.py    # Detect labels via Rekognition
│  ├─ ddb_write_handler.py      # Persist features into DynamoDB
│  ├─ export_to_s3_for_personalize.py  # Nightly export to S3 (CSV)
│  └─ common.py                 # Shared helpers
├─ statemachine/
│  └─ feature_extraction.asl.json
├─ scripts/
│  └─ personalize_bootstrap.py  # One-click-ish bootstrap for Personalize
├─ tests/
│  └─ test_handlers_smoke.py
├─ data/sample_images/.gitkeep
├─ requirements.txt
└─ README.md
```

## Notes
- This repo uses **least-privilege** IAM where possible, but review policies
  for your environment prior to production.
- If you'd rather use **Amazon SageMaker** (Option B), you can build a
  similarity model from Rekognition labels; plug it at the API layer instead
  of Personalize. (Not included here to keep the stack concise.)

## Cleanup
```bash
sam delete
```
