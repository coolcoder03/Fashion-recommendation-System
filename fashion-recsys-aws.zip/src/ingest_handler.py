import json
import os
import boto3

STATE_MACHINE_ARN = os.environ["STATE_MACHINE_ARN"]
sf = boto3.client("stepfunctions")

def lambda_handler(event, context):
    # EventBridge (from S3) delivers detail with bucket/key
    detail = event.get("detail", {})
    bucket = detail.get("bucket", {}).get("name")
    key = detail.get("object", {}).get("key")
    if not bucket or not key:
        # Try S3 Put event (if wired directly) fallback
        if event.get("Records"):
            record = event["Records"][0]
            bucket = record["s3"]["bucket"]["name"]
            key = record["s3"]["object"]["key"]

    if not bucket or not key:
        raise ValueError("Bucket/Key not found in event")

    input_payload = {
            "bucket": bucket,
            "key": key,
            "s3uri": f"s3://{bucket}/{key}"
    }

    response = sf.start_execution(
        stateMachineArn=STATE_MACHINE_ARN,
        input=json.dumps(input_payload)
    )

    return {"startedExecutionArn": response["executionArn"], "input": input_payload}
