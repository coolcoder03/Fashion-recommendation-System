import boto3

rek = boto3.client("rekognition")

def lambda_handler(event, context):
    # event carries: { bucket, key, s3uri }
    bucket = event.get("bucket")
    key = event.get("key")
    if not bucket or not key:
        raise ValueError("Missing bucket/key")

    resp = rek.detect_labels(
        Image={"S3Object": {"Bucket": bucket, "Name": key}},
        MaxLabels=25,
        MinConfidence=70.0
    )

    labels = [{"Name": l["Name"], "Confidence": round(l["Confidence"], 2)} for l in resp.get("Labels", [])]

    # extract primitive categories from parent labels
    categories = list({ p["Name"] for l in resp.get("Labels", []) for p in l.get("Parents", []) }) or None

    return {
        "bucket": bucket,
        "key": key,
        "labels": labels,
        "categories": categories
    }
