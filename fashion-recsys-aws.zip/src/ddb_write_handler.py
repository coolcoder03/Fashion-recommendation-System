import os, time, uuid
import boto3

table_name = os.environ["DDB_TABLE_NAME"]
ddb = boto3.resource("dynamodb").Table(table_name)

def lambda_handler(event, context):
    # event contains rekognition output
    bucket = event.get("bucket")
    key = event.get("key")
    labels = event.get("labels", [])
    categories = event.get("categories") or []

    # Derive productId from key prefix or name, else UUID4
    base = key.split("/")[-1].split(".")[0]
    product_id = base if base else str(uuid.uuid4())

    # Serialize labels
    rekoLabels = [l["Name"] for l in labels]
    rekoAttributes = { l["Name"]: float(l["Confidence"]) for l in labels }

    item = {
        "productId": product_id,
        "imageS3Url": f"s3://{bucket}/{key}",
        "rekoLabels": rekoLabels,
        "rekoAttributes": rekoAttributes,
        "productDetails": {
            "createdAt": int(time.time()),
            "categories": categories
        }
    }
    ddb.put_item(Item=item)
    return {"productId": product_id, "wrote": True}
