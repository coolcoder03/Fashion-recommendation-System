import os

DDB_TABLE_NAME = os.environ.get("DDB_TABLE_NAME")
PROCESSED_DATA_BUCKET = os.environ.get("PROCESSED_DATA_BUCKET")
