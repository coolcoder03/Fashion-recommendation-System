import os, csv, io, time
import boto3

ddb = boto3.resource("dynamodb")
s3 = boto3.client("s3")

TABLE = os.environ["DDB_TABLE_NAME"]
BUCKET = os.environ["PROCESSED_DATA_BUCKET"]

# CSV schema for Personalize "Items" dataset (example):
# ITEM_ID,TITLE,GENRES,LABELS,IMAGE_URL
HEADER = ["ITEM_ID","TITLE","GENRES","LABELS","IMAGE_URL"]

def lambda_handler(event, context):
    table = ddb.Table(TABLE)
    scan_kwargs = {}
    items = []
    while True:
        resp = table.scan(**scan_kwargs)
        items.extend(resp.get("Items", []))
        if "LastEvaluatedKey" in resp:
            scan_kwargs["ExclusiveStartKey"] = resp["LastEvaluatedKey"]
        else:
            break

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(HEADER)

    for it in items:
        item_id = it.get("productId")
        title = item_id
        genres = "|".join(it.get("productDetails", {}).get("categories", []) or [])
        labels = "|".join(it.get("rekoLabels", []) or [])
        image_url = it.get("imageS3Url")
        writer.writerow([item_id, title, genres, labels, image_url])

    key = f"personalize/items/items_{int(time.time())}.csv"
    s3.put_object(Bucket=BUCKET, Key=key, Body=buf.getvalue().encode("utf-8"))
    return {"wrote": f"s3://{BUCKET}/{key}", "count": len(items)}
