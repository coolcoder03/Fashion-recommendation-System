import json
from importlib import import_module

def test_ingest_handler_smoke():
    mod = import_module("src.ingest_handler")
    assert callable(mod.lambda_handler)

def test_rekognition_handler_smoke():
    mod = import_module("src.rekognition_handler")
    assert callable(mod.lambda_handler)

def test_ddb_writer_handler_smoke():
    mod = import_module("src.ddb_write_handler")
    assert callable(mod.lambda_handler)
